# Alberta Pathfinding Tool (Prototype)

Open-source Streamlit app for searching small business programs, funding and supports in Alberta.

## Run
```bash
pip install -r requirements.txt
streamlit run app.py
```
